import Role from "./Role"

export const roles: Role[] = [
    new Role("Survival", "<@&1015563733470289931>"),
    new Role("Interception","<@&1015564120906534975>"),
    new Role("Disruption", "<@&1015564128649216020>"),
    new Role("Excavation", "<@&1015564131039977493>")
]